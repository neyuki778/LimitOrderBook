#include "Book.h"
#include<iostream>

// Trades Book::place_order(OrderPointer& order) {
// 	if (order->get_price() <= 0)
// 		return {};

// 	Trades trades;
// 	id_to_order[order->get_id()] = order;

// 	if (order->get_type() == BUY) {
// 		while (best_sell and order->get_price() >= best_sell and order->get_status() != FULFILLED) {
// 			Trades trades_at_limit = sell_limits[best_sell]->match_order(order);
// 			trades.insert(trades.end(), trades_at_limit.begin(), trades_at_limit.end());
// 			check_for_empty_sell_limit(best_sell);
// 		}
// 	} else {
// 		while (best_buy and order->get_price() <= best_buy and order->get_status() != FULFILLED) {
// 			Trades trades_at_limit = buy_limits[best_buy]->match_order(order);
// 			trades.insert(trades.end(), trades_at_limit.begin(), trades_at_limit.end());
// 			check_for_empty_buy_limit(best_buy);
// 		}
// 	}

// 	if (order->get_status() != FULFILLED)
// 		insert_order(order);
// 	return trades;
// }

Trades Book::place_order(ID id, ID agent_id, OrderType type, Price price, Volume volume) {
	// 价格检查
    if (price <= 0)
		return {};

    // --- 使用内存池创建 Order 对象 ---
    // 1. 检查是否已存在相同 ID 的订单 (可选但推荐)
    if (id_to_order.count(id)) {
         // 处理重复订单 ID 的情况，例如返回错误或忽略
         std::cerr << "Warning: Order ID " << id << " already exists." << std::endl;
         return {};
    }

	// 2. 使用 order_pool 分配和构造 Order 对象
	Order* raw_order_ptr = order_pool.malloc();
	if (raw_order_ptr) {
		new(raw_order_ptr) Order(id, agent_id, type, price, volume);
	} else {
		throw std::bad_alloc();
	}
	//Order* raw_order_ptr = order_pool.construct(id, agent_id, type, price, volume);
	if (!raw_order_ptr) {
		// 处理内存分配失败
		throw std::bad_alloc();
	}

	// 3. 创建自定义删除器
	auto order_deleter = [this](Order* p) {
		this->order_pool.destroy(p);
	};

	// 4. 创建 shared_ptr 管理裸指针
	OrderPointer order = std::shared_ptr<Order>(raw_order_ptr, order_deleter);
    // --- End Order 对象创建 ---


    // --- 接下来的逻辑与之前类似，但使用新创建的 'order' ---
	Trades trades;
	id_to_order[order->get_id()] = order; // 将 shared_ptr 存入 map

	if (order->get_type() == BUY) {
		// 注意：这里 price 来自参数，不再是 order->get_price()，因为 order 是新创建的
        // 但逻辑上应该是一样的，使用 order->get_price() 也没问题
		while (best_sell != 0 && order->get_price() >= best_sell && order->get_status() != FULFILLED) {
			// get_or_create_limit 内部已修改为使用 pool
			LimitPointer sell_limit = get_or_create_limit(best_sell, false); // 获取 Limit 指针
            if (!sell_limit) continue; // 防御性编程

			Trades trades_at_limit = sell_limit->match_order(order); // 使用 Limit 对象
			trades.insert(trades.end(), trades_at_limit.begin(), trades_at_limit.end());
			check_for_empty_sell_limit(best_sell); // 检查 Limit 是否变空
		}
	} else { // SELL order
		while (best_buy != 0 && order->get_price() <= best_buy && order->get_status() != FULFILLED) {
            LimitPointer buy_limit = get_or_create_limit(best_buy, true);
            if (!buy_limit) continue;

			Trades trades_at_limit = buy_limit->match_order(order);
			trades.insert(trades.end(), trades_at_limit.begin(), trades_at_limit.end());
			check_for_empty_buy_limit(best_buy);
		}
	}

	// 如果订单未完全成交，将其插入对应的 Limit
	if (order->get_status() != FULFILLED) {
        LimitPointer limit = get_or_create_limit(order->get_price(), order->get_type() == BUY);
        if (limit) {
             insert_order(order); // 这个辅助函数现在需要接收 OrderPointer
        }
    }
    // --- End 之前逻辑 ---

	return trades;
}

void Book::delete_order(ID id) {
	if (not id_to_order.contains(id))
		return;
	OrderPointer order = id_to_order[id];
	/*if (not buy_limits.contains(order->get_price()) and not sell_limits.contains(order->get_price()))
		return;*/
	if (order->get_status() == ACTIVE) {
		delete_order(order, order->get_type() == BUY);
	}
}


bool Book::is_in_buy_limits(Price price) {
	return buy_limits.contains(price);
}

bool Book::is_in_sell_limits(Price price) {
	return sell_limits.contains(price);
}

void Book::update_best_buy() {
	if (not buy_tree.empty())
		best_buy = *buy_tree.rbegin();
	else
		best_buy = 0;
}

void Book::update_best_sell() {
	if (not sell_tree.empty())
		best_sell = *sell_tree.begin();
	else
		best_sell = 0;
}

void Book::check_for_empty_buy_limit(Price price) {
	if (is_in_buy_limits(price) and buy_limits[price]->is_empty()) {
		buy_limits.erase(price);
		buy_tree.erase(price);
		if (price == best_buy)
			update_best_buy();
	}
}

void Book::check_for_empty_sell_limit(Price price) {
	if (is_in_sell_limits(price) and sell_limits[price]->is_empty()) {
		sell_limits.erase(price);
		sell_tree.erase(price);
		if (price == best_sell)
			update_best_sell();
	}
}

void Book::insert_order(OrderPointer& order) {
	Price price = order->get_price();
	bool is_buy = order->get_type() == BUY;

	LimitPointer limit = get_or_create_limit(price, is_buy);

	if (!limit) return;

	if (is_buy and (not best_buy or price > best_buy)) {
		best_buy = price;
	} else if (not is_buy and (not best_sell or price < best_sell)) {
		best_sell = price;
	}

	limit->insert_order(order);
}

LimitPointer Book::get_or_create_limit(Price price, bool is_buy) {
	// LimitPointer limit;
	// if (is_buy) {
	// 	if (is_in_buy_limits(price)) {
	// 		limit = buy_limits[price];
	// 	} else {
	// 		limit = std::make_shared<Limit>(price);
	// 		buy_tree.insert(price);
	// 		buy_limits[price] = limit;
	// 	}
	// } else {
	// 	if (is_in_sell_limits(price)) {
	// 		limit = sell_limits[price];
	// 	} else {
	// 		limit = std::make_shared<Limit>(price);
	// 		sell_tree.insert(price);
	// 		sell_limits[price] = limit;
	// 	}
	// }
	// return limit;
	auto& limits = is_buy ? buy_limits : sell_limits;
	auto it = limits.find(price);

	if (it != limits.end()) {
		return it->second; // Limit 已存在，直接返回
	} else {
		// Limit 不存在，需要使用内存池创建
		auto& tree = is_buy ? buy_tree : sell_tree;

		// 1. 使用 limit_pool 分配和构造 Limit 对象
		Limit* raw_limit_ptr = limit_pool.construct(price);
		if (!raw_limit_ptr) {
			// 处理内存分配失败，例如抛出异常或返回空指针
			throw std::bad_alloc(); // 或者根据你的错误处理策略
		}

		// 2. 创建自定义删除器，捕获 this 指针以访问 limit_pool
        // 注意：这里捕获 this 需要确保 Book 对象比 shared_ptr 活得长
        // 由于 limit_pool 是 Book 的成员，通常是安全的
		auto limit_deleter = [this](Limit* p) {
			this->limit_pool.destroy(p); // 析构对象并将内存归还给池
		};

		// 3. 创建 shared_ptr 管理裸指针
		LimitPointer limit = std::shared_ptr<Limit>(raw_limit_ptr, limit_deleter);

		// 4. 将新的 Limit 添加到 map 和 tree 中
		limits.emplace(price, limit); // 使用 emplace 避免额外拷贝
		tree.insert(price);

		return limit;
	}

}

void Book::delete_order(OrderPointer& order, bool is_buy) {
	if (is_buy) {
		if (not is_in_buy_limits(order->get_price()))
			return;
		buy_limits[order->get_price()]->delete_order(order);
		check_for_empty_buy_limit(order->get_price());
	} else {
		if (not is_in_sell_limits(order->get_price()))
			return;
		sell_limits[order->get_price()]->delete_order(order);
		check_for_empty_sell_limit(order->get_price());
	}
}

void Book::print() {
	for (Price price : buy_tree){
		buy_limits[price]->print();
	}
	std::cout << "==== BUY SIDE ===" << std::endl;
	std::cout << "Best buy: " << best_buy << std::endl;
	std::cout << "Best sell: " << best_sell << std::endl;
	std::cout << "=== SELL SIDE ===" << std::endl;
	for (Price price : sell_tree){
		sell_limits[price]->print();
	}
}

Price Book::get_spread() {
	return best_sell - best_buy;
}
double Book::get_mid_price() {
	return (best_sell + best_buy) / 2.;
}

PriceTree& Book::get_buy_tree() { return buy_tree; }
PriceLimitMap& Book::get_buy_limits() { return buy_limits; }
PriceTree& Book::get_sell_tree() { return sell_tree; }
PriceLimitMap& Book::get_sell_limits() { return sell_limits; }
Price Book::get_best_buy(){ return best_buy; }
Price Book::get_best_sell() { return best_sell; }
Orders& Book::get_id_to_order() { return id_to_order; }
OrderStatus Book::get_order_status(ID id) {
	if (id_to_order.contains(id))
		return id_to_order[id]->get_status();
	return DELETED;
}
