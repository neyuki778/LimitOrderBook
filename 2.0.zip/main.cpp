#include "demo/demo.cpp"

int main() {
	demo();
	return 0;
}